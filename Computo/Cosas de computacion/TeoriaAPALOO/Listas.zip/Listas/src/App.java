
public class App {
    public static void main(String[] args) throws Exception {
     
        System.out.println("Creando Listas con Arreglos  (ArrayList)");
          // Crear una lista de alumnos con capacidad 3
        ArrayList<Alumno> listaAlumnos = new ArrayList<>(3);

        // Verificar si la lista está vacía
        System.out.println("¿La lista está vacía? " + listaAlumnos.esVacia());
        System.out.println("Número de alumnos: " + listaAlumnos.getnumElementos());
        System.out.println(listaAlumnos);

        //Agregando alumnos a  mi lista
        listaAlumnos.agregarFinal(new Alumno(10000, "Hugo Roque", 9.5));
        listaAlumnos.agregarFinal(new Alumno(10001, "Ana Pérez", 8.7));
        listaAlumnos.agregarFinal(new Alumno(10002, "Luis Carmona", 9.0));

        // Mostrando la lista
        System.out.println("¿La lista está vacía? " + listaAlumnos.esVacia());
        System.out.println("Número de alumnos: " + listaAlumnos.getnumElementos());
        System.out.println(listaAlumnos);

        //Eliminando un elemento
        Alumno a=listaAlumnos.eliminarInicio();
        System.out.println("Alumno Eliminado");
        System.out.println(a);


        // Mostrando la lista despues de la eliminacion
        System.out.println("Número de alumnos: " + listaAlumnos.getnumElementos());
        System.out.println(listaAlumnos);
    }
    
}
