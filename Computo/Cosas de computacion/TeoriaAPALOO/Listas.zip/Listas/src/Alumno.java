public class Alumno {
    private int id;
    private String nombre;
    private double promedio;

    public Alumno(int id, String nombre, double promedio) {
        this.id = id;
        this.nombre = nombre;
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return id + " - " + nombre + " - Promedio: " + promedio;
    }
}
