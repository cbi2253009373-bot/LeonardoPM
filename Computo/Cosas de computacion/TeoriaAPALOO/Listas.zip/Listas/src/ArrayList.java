
public class ArrayList<E> implements Lista<E> {

    private  int capacidad;
	private int indice=0;
	private Object[] datos=null; 


	public ArrayList(int capacidad) {

		if(capacidad<0){
			throw new IllegalArgumentException();
		}
        this.capacidad=capacidad;
		datos = new Object[capacidad];

	}

    @Override
	public boolean esVacia() {

		return(indice==0);
	}

	@Override
	public int getnumElementos() {
		return indice;
	}

	@Override
	public void limpiarLista() {
		indice = 0;
		limpiarReferencias(); //este metodo no es abstracto solo lo usamos aqui. 

	}


	private void limpiarReferencias(){

		for(int i=0;i<datos.length;i++){
			datos[i]=null;
		}
	}


	public void agregarFinal(E e) {

		Object[] aux=null;
		//Verificamos si esa Lleno
		if(this.indice==this.capacidad){
			//Si esta lleno entonces agrandamos el arreglo solicitando uno nuevo
			int nuevaCapacidad=datos.length+datos.length/2;
			this.capacidad=nuevaCapacidad;
			aux = new Object[capacidad];
			System.arraycopy(datos,0,aux,0,datos.length);
			//DEBEMOS ELIMINAR TODAS LAS REFERENCIAS DEL ARREGLO ORIGINAL PARA QUE NO SE CONFUNDAN REFERNCIAS
			limpiarReferencias();
			this.datos = aux;
		}
		//Cuando hay espacion entonces lo agregamos al final
		this.datos[this.indice] = e;
		this.indice++;
	}


	

	@Override
    public String toString() {
    if (indice == 0) return "Lista vacía";

    StringBuilder sb = new StringBuilder("");
    for (int i = 0; i < indice; i++) {
		sb.append((i+1)+".-");
        sb.append(datos[i]);
        if (i < indice - 1){
				sb.append("\n");
		}
    }
    return sb.toString();
}

	@SuppressWarnings("unchecked")
	@Override
	public E eliminarInicio() {
		if(!esVacia()){
			E aux =  null;
			aux = (E)datos[0];
			//Recorremos los datos hacía arriba
			System.arraycopy(datos,1,datos,0,indice-1);
			indice--;
			return aux;
		}//Si es vacia lanzamos un error
		throw new NullPointerException();
	}

	
}

